package main;

public interface Observer
{
    void update(int timeStep);
}
